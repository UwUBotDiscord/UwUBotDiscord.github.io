function download(url, file)
  local content = http.get(url).readAll()
  if not content then
    error("Could not connect to website")
  end
  f = fs.open(file, "w")
  f.write(content)
  f.close()
end

download("https://oxmc.github.io/Astrobuild2/ver.txt", "ver.txt")